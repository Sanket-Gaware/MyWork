<?php
       
                
        if(isset($_REQUEST['logIn']))
        {
             require ('Connection.php');
            $email=$_REQUEST['email'];
            $password=$_REQUEST['password'];
            if($email=="" || $password=="" || !filter_var($email,FILTER_VALIDATE_EMAIL))
            {
                header("location: professional_login.php");
            }
            else
            {
                $query= "select aid,name,email from `admin` where email='$email' and password='$password'";
                $result=  mysqli_query($con, $query);
                $id= mysqli_fetch_array($result);
                $row = mysqli_num_rows($result);
                if($row != 0)
                {
                    session_start();
                    $_SESSION['aid']=$id[0];
                    $_SESSION['name']=$id[1];
                    $_SESSION['email']=$id[2];
                    header("location: Dashboard.php");
               }
               else
               {
                    header("location: professional_login.php");
               }
               
                    
            }
        }
    
?>
