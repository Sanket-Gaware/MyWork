

<?php

if(isset($_REQUEST['submit']))
{
   
    require ('Connection.php');
    function filter($data)
    {
     
        $data=  trim($data);
        $data=  stripslashes($data);
        $data= htmlspecialchars($data);
        return $data;
    }
    $fname=$_REQUEST['username'];
    $fname=  filter($fname);
  
  
   
    $email=$_REQUEST['email'];
    $mobile_number= $_REQUEST['mobi'];
    $mobile_number=  filter($mobile_number); 
      $street1=$_REQUEST['street1'];
    $street1=  filter($street1);

  $street2=$_REQUEST['street2'];
    $street2=  filter($street2);
    
    $city=$_REQUEST['city'];
    $city=  filter($city);
    $state=$_REQUEST['state'];
    $state=  filter($state);
    
    $zipcode=$_REQUEST['zipcode'];
    $zipcode=filter($zipcode);

 $country=$_REQUEST['country'];
    $country=filter($country);
    $shoe=$_REQUEST['shoe'];
    $pair=$_REQUEST['pair'];
    $reg_date=  date("Y-m-d H:i:s");
    $price=0;
   // echo $gender.$email.$mobile_number;
    
    if(!ctype_alpha($fname) ||$fname==""   || $email==""  || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($mobile_number)> 10 || strlen($mobile_number)< 10         || $street1=="" || $street2=="" || strcmp($city,"Mumbai") || $state=="" || $zipcode=="" ||$country=="" )
    {     
        header("location: select_type.php");
      
    }  
    else
    {
    				$priceR=mysqli_query($con,"select ".$shoe." from `price`");
    				$id_rowR= mysqli_num_rows($priceR);
                       $idR=  mysqli_fetch_array($priceR);
                       if($id_rowR != 0)
                       {
                          echo $idR[0]; 
                          $price=$pair*$idR[0];
                       }
        
                    $fname=  mysqli_real_escape_string($con,$fname);
                   

                    $mobile_number=  mysqli_real_escape_string($con,$mobile_number);
                     $query="INSERT INTO `book`(`uname`, `email`, `mobile`, `street1`, `stree2`, `city`, `state`, `zipcode`, `country`, `shoe`, `pair`,`price`,`date`,`arrived`, `processing`, `complete`) VALUES ('$fname','$email','$mobile_number','$street1', '$street2', '$city', '$state', '$zipcode', '$country','$shoe','$pair','$price','$reg_date','0','0','0')";
                    $result=  mysqli_query($con, $query);
                    if($result)
                    {
                         $id_result=  mysqli_query ($con,"select bid from `book` where email='$email'");
                       $id_row= mysqli_num_rows($id_result);
                       $id=  mysqli_fetch_array($id_result);
                       if($id_row != 0)
                       {
                           session_start();
                           $_SESSION['bid']=$id[0];
                           header("location: invoice.php");   
                       	
                       }
                       
                        
                    }
                    else
                    {
                        echo "insert error";
                    }
              
    }
}

?>



