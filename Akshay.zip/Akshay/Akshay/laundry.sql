-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2017 at 02:08 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `name`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '1234567890');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `bid` int(40) NOT NULL,
  `uname` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile` varchar(40) NOT NULL,
  `street1` varchar(40) NOT NULL,
  `stree2` varchar(40) NOT NULL,
  `city` varchar(40) NOT NULL,
  `state` varchar(40) NOT NULL,
  `zipcode` varchar(40) NOT NULL,
  `country` varchar(40) NOT NULL,
  `shoe` varchar(40) NOT NULL,
  `pair` varchar(40) NOT NULL,
  `price` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `arrived` int(11) NOT NULL,
  `processing` int(10) NOT NULL,
  `complete` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`bid`, `uname`, `email`, `mobile`, `street1`, `stree2`, `city`, `state`, `zipcode`, `country`, `shoe`, `pair`, `price`, `date`, `arrived`, `processing`, `complete`) VALUES
(1, 'sam', 'sam@gmail.com', '9930899277', 'jasai', 'jasai', 'uran', 'mh', '410206', 'india', 'sport', '2', '0', '0000-00-00', 0, 0, 0),
(4, 'b', 'b@gmail.com', '9930899277', 'a', 'a', 'Mumbai', 'MH', '410206', 'India', 'sport shoe', '1', '0', '2017-03-12', 1, 1, 1),
(5, 'c', 'c@gmail.com', '9930899277', 'a', 'a', 'Mumbai', 'MH', '410206', 'India', 'knee', '2', '0', '2017-03-12', 0, 0, 1),
(6, 'c', 'c@gmail.com', '9930899277', 'a', 'a', 'Mumbai', 'MH', '410206', 'India', 'knee', '2', '0', '2017-03-12', 1, 1, 1),
(7, 'c', 'c@gmail.com', '9930899277', 'a', 'a', 'Mumbai', 'MH', '410206', 'India', 'knee', '2', '0', '2017-03-12', 0, 1, 1),
(8, 'c', 'c@gmail.com', '9930899277', 'a', 'a', 'Mumbai', 'MH', '410206', 'India', 'knee', '2', '1998', '2017-03-12', 0, 0, 0),
(9, 'c', 'c@gmail.com', '9930899277', 'a', 'a', 'Mumbai', 'MH', '410206', 'India', 'knee', '2', '1998', '2017-03-12', 0, 0, 0),
(10, 'd', 'd@gmail.com', '9930899277', 'a', 'a', 'Mumbai', 'MH', '420607', 'India', 'canvas', '2', '598', '2017-03-12', 0, 0, 0),
(11, 'mukul', 'mukul@gmail.com', '9820378598', 'sec 21', '778', 'Mumbai', 'MH', '410206', 'India', 'leather', '4', '1596', '2017-03-12', 0, 0, 0),
(12, 'rushi', 'rushi@gmail.com', '9920611167', 'ssss', 'ss', 'Mumbai', 'MH', '410206', 'India', 'canvas', '2', '598', '2017-03-12', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `msg` varchar(500) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `mobile`, `msg`, `date`) VALUES
('sam', 'sam@gmail.com', '9930899277', 'feedback', '0000-00-00'),
('mukul', 'mukul@gmail.com', '9820378598', 'xyz', '2017-03-12');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `bid` int(10) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`bid`, `message`) VALUES
(6, 'hiii all processed'),
(6, 'hiii all processed'),
(11, 'welcome');

-- --------------------------------------------------------

--
-- Table structure for table `msg_admin`
--

CREATE TABLE `msg_admin` (
  `bid` int(10) NOT NULL,
  `message` varchar(500) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `msg_admin`
--

INSERT INTO `msg_admin` (`bid`, `message`, `date`) VALUES
(11, 'sam', '2017-03-12'),
(11, 'sam', '2017-03-12'),
(12, 'rushi', '2017-03-12');

-- --------------------------------------------------------

--
-- Table structure for table `price`
--

CREATE TABLE `price` (
  `sport` int(11) NOT NULL,
  `canvas` int(11) NOT NULL,
  `heels` int(11) NOT NULL,
  `leather` int(11) NOT NULL,
  `ankle` int(11) NOT NULL,
  `knee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `price`
--

INSERT INTO `price` (`sport`, `canvas`, `heels`, `leather`, `ankle`, `knee`) VALUES
(299, 299, 299, 399, 699, 999);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`bid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `bid` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
