<?php
$con=  mysqli_connect("localhost","root","" ,"laundry")or die(mysql_error());
if(mysqli_connect_errno())
{
    echo "Failed to connect to database";
}
?>

