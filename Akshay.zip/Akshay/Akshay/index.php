<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
</head>

<body>
<?php
session_start();
session_destroy();

?>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li  role="presentation"><a href="features.php">Book Now</a></li>
                    <li role="presentation"><a href="professional_login.php">Admin LogIn</a></li>
                    <li role="presentation"><a href="view.php">User LogIn</a></li>
                    
                    <li role="presentation"><a href="about.php">About Us</a></li>
                    <li role="presentation"><a href="contact_us.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav><img src="bg1.jpg" width="100%" height="100%">
    <div class="col-lg-7 col-lg-offset-3 col-md-6">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Shoe Type</th>
                        <th>Price </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>sport shoe </td>
                        <td>299 </td>
                    </tr>
                    <tr>
                        <td>canvas sneakers </td>
                        <td>299 </td>
                    </tr>
                    <tr>
                        <td>Heels/Sandals </td>
                        <td>299 </td>
                    </tr>
                    <tr>
                        <td>Leather/Suede </td>
                        <td>399 </td>
                    </tr>
                    <tr></tr>
                    <tr>
                        <td>Ankle length suede/Leather </td>
                        <td> 699</td>
                    </tr>
                    <tr>
                        <td>knee suede/Leather </td>
                        <td>999 </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <br>
    <div class="col-lg-offset-5 col-md-7">
       <a href="features.php"><button type="submit">Book</button>
    </div>
   
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>