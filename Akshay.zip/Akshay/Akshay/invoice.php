
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shoe Clinic - Invoice</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
    <style type="text/css">
    	ul.b {list-style-type: square;
    			font-size: 15px;
    	}
    </style>
</head>

<body>
<?php
 require ('Connection.php');
 session_start();
         $bid=$_SESSION['bid'];

           if($bid==null)
        {
            header("location:index.php");
        }
        
              


?>
     <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                 <li role="presentation"><a href="index.php">Home </a></li>
                    <li class="active" role="presentation"><a href="features.php">Book Now</a></li>
                    <li role="presentation"><a href="professional_login.php">Admin LogIn</a></li>
                    <li role="presentation"><a href="view.php">User LogIn</a></li>
                    
                    <li role="presentation"><a href="about.php">About Us</a></li>
                    <li role="presentation"><a href="contact_us.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="col-lg-7 col-lg-offset-3 col-md-6" style="margin-left: 25%;">
            <h1>Invoice</h1>
            <h3>Shoe Laundry And Repair</h3>
            <table class="table">

            <?php
             $query = "SELECT  *FROM `book` where bid='$bid'";

              //echo $query;
              $result  = mysqli_query($con, $query);
              $revenue = 0;
              if (mysqli_affected_rows($con) != 0) 
              {
                  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                   {
                    echo "<tr><th>Order Id</th><th>".$row["bid"]."</th>";
                     echo "<tr><th>Name:-</th><th>".$row["uname"]."</th></tr>";
                     echo "<tr><th>Contact No:-</th><th>".$row["mobile"]."</th></tr>";
                    echo "</table>";
                    echo "<table class='table'>";
                    echo "<tr><th>Qty</th><th>Item Name</th><th>Price</th></tr>";
                    echo "<tr><td>".$row["pair"]."</td><td>".$row["shoe"]."</td><td>".$row["price"]."</td></tr>";
                    echo "<tr><td></td><td></td><td>Total:-".$row["price"]."</td></tr>";
                    echo "<tr><td colspan='3'>We Will Reach on your given Address between 8 am to 8 pm.</td></tr>";
                     echo "<tr><td colspan='3'>Please Note Down Order Id</td></tr>";
                    echo "</table>";
                     

                  }
              }
              ?>
              <a href="index.php"><button type="submit" style="margin-left: 25%;">Home </button></a>
              

    </div>
    
    <div class="col-lg-offset-0 col-md-12 col-md-offset-4"></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>