<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
</head>

<body>
 <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active" role="presentation"><a href="view-new.php">View New Orders</a></li>

                    <li role="presentation"><a href="Dashboard.php"> Dashboard</a></li>
                    
                    <li role="presentation"><a href="check-status.php"> Check Status</a></li>
                    <li role="presentation"><a href="view-order-id.php"> View Order Id </a></li>
                    <li role="presentation"><a href="message.php">Message</a></li>
                    
                       <li role="presentation"><a href="report.php">Report</a></li>
                        <li role="presentation"><a href="send-notofication.php">Send Notification</a></li>
                     
                
                    <li role="presentation"><a href="Log_out.php">log Out</a></li>
                </ul>
            </div>
        </div>
    </nav>


<?php
 require ('Connection.php');
                    session_start();
                    $aid=$_SESSION['aid'];
                    $name=$_SESSION['name'];
                    $email=$_SESSION['email'];

           if($aid==null)
        {
            header("location:index.php");
        }
        if(isset($_REQUEST['change']))
        {
            $s=$_REQUEST['ch'];
            $b=$_REQUEST['change'];
            $update=mysqli_query($con,"UPDATE `book` SET ".$s."=1 WHERE bid='$b'");
            if($update)
            {
                echo "<h1>status changed</h1>";
            }
        }
        ?>
        <form action="change.php" method="POST">

        <?php
        
             if(isset($_REQUEST['submit']))
             {
                $bid=$_REQUEST['submit'];
             	 $query = "select  *from `book` where bid='$bid'";
                 $status="no status";
              $result  = mysqli_query($con, $query);
              $revenue = 0;
              if (mysqli_affected_rows($con) != 0) 
              {
                  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                   {
                    if($row["complete"]==1)
                    {
                            $status="Complete";
                    }
                    else if ($row["processing"]==1) 
                    {
                       $status="processing";
                    }
                    else if($row["arrived"]==1)
                    {
                        $status="Arrived";
                    }
                    else
                    {
                        $staus="No status";
                    }


                   echo "     <table class='table'>";
                    echo "<tr><th>Order Id</th><th>".$row["bid"]."</th>";
                     echo "<tr><th>Name:-</th><th>".$row["uname"]."</th></tr>";
                     echo "<tr><th>Contact No:-</th><th>".$row["mobile"]."</th></tr>";
                    echo "</table>";
                    echo "<table class='table'>";
                    echo "<tr><th>Qty</th><th>Item Name</th><th>Price</th></tr>";
                    echo "<tr><td>".$row["pair"]."</td><td>".$row["shoe"]."</td><td>".$row["price"]."</td></tr>";
                    echo "<tr><td></td><td></td><td>Total:-".$row["price"]."</td></tr>";
                    echo "<tr><th>Current Status:-".$status."</th><th>Change Status<select name='ch'><option value='complete'>Complete</option><option value='processing'>Processing</option><option value='arrived'>Arrived</option></select></th>";
                    //"<th><button type='submit' name='change' value=".$row["bid"].">Chnage Status</button></th></tr>";
                                    
                    echo "</table>";
                    echo"<center>";
                    echo"<button type='submit' name='change' value=".$row["bid"].">Chnage Status</button>";
                    echo"</center>";
                  }
              }
             } 
             if(isset($_REQUEST['delete']))
             {
             	$bid=$_REQUEST['delete'];
                $delete=mysqli_query($con,"DELETE FROM `book` WHERE bid='$bid'");
                if($delete)
                {
                    echo "<h1>Delete Successfuly</h1>";
                }
             }
?>
</form>


  <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>


</html>