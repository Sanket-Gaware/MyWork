<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
     <style type="text/css">
.val_error{
    color: #FF1F1F;
}

      </style>
        <script type="text/javascript">
            
    
            function Validate() 
            {
            var regex = /^([0-9a-zA-Z]([-_\\.]*[0-9a-zA-Z]+)*)@([0-9a-zA-Z]([-_\\.]*[0-9a-zA-Z]+)*)[\\.]([a-zA-Z]{2,9})$/;
            
                var email = document.getElementById("email").value;
        
                if (!regex.test(email) || email=="")
                  {
                    
                                            
                    document.getElementById("email").style.borderColor="red";
                    email_error.textContent = "Email is required";
                        return false;
                  
                  }
                 
                 else
                 {
                    return true;
                 }

                
            }
        
        </script>
</head>

<body>

     <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                 <li role="presentation"><a href="index.php">Home </a></li>
                    <li role="presentation"><a href="features.php">Book Now</a></li>
                    <li role="presentation"><a href="professional_login.php">Admin LogIn</a></li>
                    <li class="active" role="presentation"><a href="view.php">User LogIn</a></li>
                    
                    <li role="presentation"><a href="about.php">About Us</a></li>
                    <li role="presentation"><a href="contact_us.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <center>
    <div class="col-md-6" style="margin-left: 28%;">
    <form action="send.php" method="POST">
  <?php
   require ('Connection.php');
   $sid=0;
          if(isset($_REQUEST['submit']))
          {
              $email=$_REQUEST['email'];
              $bid=$_REQUEST['order'];
              
                $mp=mysqli_query($con,"select *from `message` where bid='$bid'");
             
                  while ($rowm = mysqli_fetch_array($mp, MYSQLI_ASSOC))
                   {
                      echo "<table class='table table-hover'>";
                      echo "<tr><th>Message</th>";
                      echo "<tr><td>".$rowm["message"]."</td></tr>";
                      echo "</table>";
                    

                  }
             
              $query = "select  *from `book` where bid='$bid' and email='$email'";

              $result  = mysqli_query($con, $query);
              $revenue = 0;
              echo "<center><h1>Order Invoice</h1></center>";
              if (mysqli_affected_rows($con) != 0) 
              {
                  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                   {
                    $status="no status";
                      $sid=$row["bid"];
                          if($row["complete"]==1)
                            {
                                    $status="Complete";
                            }
                            else if ($row["processing"]==1) 
                            {
                               $status="processing";
                            }
                            else if($row["arrived"]==1)
                            {
                                $status="Arrived";
                            }
                            else
                            {
                                $staus="No status";
                            }
                   echo "     <table class='table table-hover'>";
                    echo "<tr><th>Order Id</th><th>".$row["bid"]."</th>";
                     echo "<tr><th>Name:-</th><th>".$row["uname"]."</th></tr>";
                     echo "<tr><th>Contact No:-</th><th>".$row["mobile"]."</th></tr>";
                    echo "</table>";
                    echo "<table class='table table-hover'>";
                    echo "<tr><th>Qty</th><th>Item Name</th><th>Price</th></tr>";
                    echo "<tr><td>".$row["pair"]."</td><td>".$row["shoe"]."</td><td>".$row["price"]."</td></tr>";
                    echo "<tr><td></td><td></td><td>Total:-".$row["price"]."</td></tr>";
                    echo "<tr><th>Status:-".$status."</th><th></th><th></th></tr>";
                   
                    
                    echo "</table>";
                  
                  }
              }
              else
              {
                  header("location: view.php");
              }
              echo "<center><h1>Send Message</h1></center>";
              echo "<textarea name='msg' rows='8' cols='40' required></textarea><br>";
              echo "<button type='submit' name='send' value=".$sid.">Send</button>";
          }




  ?>
  </form>
  </div>
  </center>
 
    <div class="col-lg-offset-0 col-md-12 col-md-offset-4"></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>