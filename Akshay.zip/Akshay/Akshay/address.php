
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
    <style type="text/css">
    	ul.b {list-style-type: square;
    			font-size: 15px;
    	}
        input[type=text], input[type=password],.field{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
    </style>
</head>


<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand navbar-link" href="#"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active" role="presentation"><a href="#">Book Now</a></li>
                    <li role="presentation"><a href="#">Professional </a></li>
                    <li role="presentation"><a href="#">About Us</a></li>
                    <li role="presentation"><a href="#">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="col-lg-7 col-lg-offset-3 col-md-6" style="margin-left: 20%;">
    <form action="" method="POST">
    <center><h2>Select Your Address</h2></center>
            <div class="container">
                          <table width="700">
                         <tr> <td><label>Enter Location</label></td><td><div id="locationField">
                                          <input id="autocomplete" placeholder="Enter your address"
                                                 onFocus="geolocate()" type="text"></input>
                                        </div></td></tr>
                                    </table>
                                        <table id="address" width="700">
                                          <tr>
                                            <td ><label><b>Street address </br> House no</b></label></td>
                                            <td class="slimField"><input class="field" id="street_number"
                                                  disabled="true" name="street1"></input></td></tr>
                                                  <tr><td></td>
                                            <td ><input class="field" id="route"
                                                  disabled="true" name="street2"></input></td>
                                          </tr>
                                          <tr>
                                            <td ><label><b>City</b></label></td>
                                          
                                            <td ><input class="field" id="locality"
                                                  disabled="true" name="city"></input></td>
                                          </tr>
                                          <tr>
                                            <td ><label><b>State</b></label></td>
                                            <td ><input class="field"
                                                  id="administrative_area_level_1" disabled="true" name="state"></input></td></tr>
                                                  <tr>
                                            <td ><label><b>Zip code</b></label></td>
                                            <td ><input class="field" id="postal_code"
                                                  disabled="true" name="zipcode"></input></td>
                                          </tr>
                                          <tr>
                                            <td ><label><b>Country</b></label></td>
                                            <td  ><input class="field"
                                                  id="country" disabled="true" name="country"></input></td>
                                          </tr>
                                          <tr>
                                            <td ><label><b>Date</b></label></td>
                                            <td  ><input type="date" ></input></td>
                                          </tr>
                            </table>

    
                          
                                
                            <button type="submit" name="submit" style="margin-left: 30%;">Next</button></br>
                            
                          </div>
                          </form>

                          
   
        
    </div>
      
    </div>
    
    <div class="col-lg-offset-0 col-md-12 col-md-offset-4"></div>
    <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAqOxxOXdbQCISpcbHlJZMNbi9UIeTAfxk&libraries=places&callback=initAutocomplete"
        async defer></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>