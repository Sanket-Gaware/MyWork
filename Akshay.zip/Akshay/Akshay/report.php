<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
    <style type="text/css">
      h2,h3{
        color: white;
      }
    </style>
</head>

<body>
 <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
<a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li  role="presentation"><a href="view-new.php">View New Orders</a></li>

                    <li role="presentation"><a href="Dashboard.php"> Dashboard</a></li>
                    
                    <li role="presentation"><a href="check-status.php"> Check Status</a></li>
                    <li role="presentation"><a href="view-order-id.php"> View Order Id </a></li>
                    <li role="presentation"><a href="message.php">Message</a></li>
                    
                       <li class="active"role="presentation"><a href="report.php">Report</a></li>
                        <li role="presentation"><a href="send-notofication.php">Send Notification</a></li>
                     
                
                    <li role="presentation"><a href="Log_out.php">log Out</a></li>
                </ul>
            </div>
        </div>
    </nav>

<?php
 require ('Connection.php');
                    session_start();
                    $aid=$_SESSION['aid'];
                    $name=$_SESSION['name'];
                    $email=$_SESSION['email'];

           if($aid==null)
        {
            header("location:index.php");
        }
  ?>
    <div class="col-sm-3">      
        <div class="tile-stats tile-red">
          <div class="icon"><i class="entypo-users"></i></div>
            <div class="num" data-postfix="" data-duration="1500" data-delay="0" style="background: #6699ff">
            <h2 align="center">Paid Income This Month</h2><br> 
          
            <?php
              $date  = date('Y-m');
              $query = "select * from book WHERE  date LIKE '$date%'";

              
              $result  = mysqli_query($con, $query);
              $revenue = 0;
              if (mysqli_affected_rows($con) != 0) 
              {
                  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) 
                  {
                      $revenue = $row['price'] + $revenue;
                  }
              }
              echo "<center><h3>";
              echo $revenue;
              echo "</h3></center>";
              ?>
            </div>
        </div>
      </div>
<div class="col-sm-3">      
        <div class="tile-stats tile-green">
          <div class="icon"><i class="entypo-chart-bar"></i></div>
            <div class="num" data-postfix="" data-duration="1500" data-delay="0" style="background: #6699ff;">
            <h2 align="center">Total Orders</h2><br>
          <center>  <h3>
              <?php
              $date  = date('Y-m');
              $query = "select COUNT(*) from book ";

              
              $result = mysqli_query($con, $query);
              $i      = 1;
              if (mysqli_affected_rows($con) != 0)
               {
                  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) 
                  {
                      echo $row['COUNT(*)'];
                  }
              }
              $i = 1;
              ?>
              </h3></center>
            </div>
        </div>
      </div>  
      <div class="col-sm-3">      
        <div class="tile-stats tile-green">
          <div class="icon"><i class="entypo-chart-bar"></i></div>
            <div class="num" data-postfix="" data-duration="1500" data-delay="0" style="background: #6699ff;">
            <h2 align="center">Todays Order</h2><br>
          <center>  <h3>
              <?php
              $date  = date('Y-m-d');
              $query = "select COUNT(*) from book ";

              
              $result = mysqli_query($con, $query);
              $i      = 1;
              if (mysqli_affected_rows($con) != 0)
               {
                  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) 
                  {
                      echo $row['COUNT(*)'];
                  }
              }
              $i = 1;
              ?>
              </h3></center>
            </div>
        </div>
      </div>  
       <div class="col-sm-3">      
        <div class="tile-stats tile-green">
          <div class="icon"><i class="entypo-chart-bar"></i></div>
            <div class="num" data-postfix="" data-duration="1500" data-delay="0" style="background: #6699ff;">
            <h2 align="center" >Pending Orders<br><br></h2>
          <center>  <h3>
              <?php
              $date  = date('Y-m-d');
              $query = "select COUNT(*) from book where complete=0 ";

              
              $result = mysqli_query($con, $query);
              $i      = 1;
              if (mysqli_affected_rows($con) != 0)
               {
                  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) 
                  {
                      echo $row['COUNT(*)'];
                  }
              }
              $i = 1;
              ?>
              </h3></center>
            </div>
        </div>
      </div>  
</br>
<form action="" method="POST">
<center><label>Date</label><input type="date" name="date"></br></center>
<center><button type="submit" name="feedback">Date</button></center>
</form><center>
<table class="table">
<tr><th>Name</th><th>Email</th><th>Mobile No</th><th>Message</th></tr>
<?php
  if(isset($_REQUEST['feedback']))
  {
    $date=$_REQUEST['date'];
  $fq=mysqli_query($con,"select *from `feedback` WHERE  date LIKE '$date%'");
   while ($rf = mysqli_fetch_array($fq, MYSQLI_ASSOC)) 
                  {
                      echo "<tr>";
                      echo "<td>".$rf["name"]."</td>";
                      echo "<td>".$rf["email"]."</td>";
                      echo "<td>".$rf["mobile"]."</td>";
                      echo "<td>".$rf["msg"]."</td>";



                  }
  }


?>
  


</table>
      

  <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>


</html>