
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
    <style type="text/css">
    	ul.b {list-style-type: square;
    			font-size: 15px;
    	}
   .borderless td, .borderless th{
  border: none;
}

            input[type=text], input[type=password],.field{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
    .val_error{
  color: #FF1F1F;
}
    </style>
     <script type="text/javascript">
            function Validate()
            {
              
              var regex = /^([0-9a-zA-Z]([-_\\.]*[0-9a-zA-Z]+)*)@([0-9a-zA-Z]([-_\\.]*[0-9a-zA-Z]+)*)[\\.]([a-zA-Z]{2,9})$/;
              var phoneno = /^[0]?[789]\d{9}$/;
              var username=document.getElementById("username").value;
             var email=document.getElementById("email").value;
               
                var mobi=document.getElementById("mobi").value;
                if (!regex.test(email) || email=="")
                  {
                    
                                                  
                    document.getElementById("email").style.borderColor="red";
                    email_error.textContent = "Email is required";
                    return false;
                  
                  }
                   
                  else if(mobi.length != 10)
                  {
                    document.getElementById("mobi").style.borderColor="red";
                    mobi_error.textContent = "Enter Valid Mobile Number";
                    return false;
                  }
                   else if (!mobi.match(phoneno) )
                  {
                                        
                      document.getElementById("mobi").style.borderColor="red";
                    mobi_error.textContent = "Enter Valid Mobile Number";
                    return false;                  
                      
                  }
                  else
                  {
                    return true;
                  }
                 







               
            }


    </script>

</head>

<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                                <a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                 <li role="presentation"><a href="index.php">Home </a></li>
                    <li class="active" role="presentation"><a href="features.php">Book Now</a></li>
                    <li role="presentation"><a href="professional_login.php">Admin LogIn</a></li>
                    <li role="presentation"><a href="view.php">User LogIn</a></li>
                    
                    <li role="presentation"><a href="about.php">About Us</a></li>
                    <li role="presentation"><a href="contact_us.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="col-lg-7 col-lg-offset-3 col-md-6" style="margin-left: 22%;">
   <h2>Which type of shoe do you want to get cleaned?</h2>
   <form action="book.php" method="POST" onsubmit="return Validate()">
   <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Shoe Type</th>
                        <th>Price </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>sport shoe </td>
                        <td>299 </td>

                    </tr>
                    <tr>
                        <td>canvas/sneakers </td>
                        <td>299 </td>
                    </tr>
                    <tr>
                        <td>Heels/Sandals </td>
                        <td>299 </td>
                    </tr>
                    <tr>
                        <td>Leather/Suede </td>
                        <td>399 </td>
                    </tr>
                    <tr></tr>
                    <tr>
                        <td>Ankle length suede/Leather </td>
                        <td> 699</td>
                    </tr>
                    <tr>
                        <td>knee suede/Leather </td>
                        <td>999 </td>
                    </tr>
                </tbody>
            </table>

        </div>
         <center><h2>Select Your Address (Only Mumbai)</h2></center>
            <div class="container">
                          <table width="700">
                         <tr>  <td><label><b>Name</b></label></td>

                                                             <td > <input type="text" placeholder="User name" name="username" id="username" required > </br>
                                                              <div id="name_error" class="val_error"></div>
                                                             </td>
                                                             
                                                              </tr>
                                                              
                                                            <tr>  <td><label><b>Email</b></label></td>

                                                             <td > <input type="text" placeholder="Enter Email" name="email" id="email" required> </br>
                                                             <div id="email_error" class="val_error"></div></td>
                                                         
                                                              </tr>
                                                               <tr> <td><label><b>Mobile No</b></label></td>
                                                           <td>   <input type="text" placeholder="Mobile No" name="mobi" id="mobi" maxlength="10" required></br>
                                                           <div id="mobi_error" class="val_error"></div>
                                                           </td>
                                                           </tr>

                         <tr> <td><label>Enter Location</label></td><td><div id="locationField">
                                          <input id="autocomplete" placeholder="Enter your address"
                                                 onFocus="geolocate()" type="text"></input>
                                        </div></td></tr>
                                    </table>
                                        <table id="address" width="700">
                                          <tr>
                                            <td ><label><b>Street address </br> House no</b></label></td>
                                            <td class="slimField"><input class="field" id="street_number"
                                                  disabled="true" name="street1"></input></td></tr>
                                                  <tr><td></td>
                                            <td ><input class="field" id="route"
                                                  disabled="true" name="street2"></input></td>
                                          </tr>
                                          <tr>
                                            <td ><label><b>City</b></label></td>
                                          
                                            <td ><input class="field" id="locality"
                                                  disabled="true" name="city"></input></td>
                                          </tr>
                                          <tr>
                                            <td ><label><b>State</b></label></td>
                                            <td ><input class="field"
                                                  id="administrative_area_level_1" disabled="true" name="state"></input></td></tr>
                                                  <tr>
                                            <td ><label><b>Zip code</b></label></td>
                                            <td ><input class="field" id="postal_code" maxlength="6" 
                                                  disabled="true" name="zipcode"></input></td>
                                          </tr>
                                          <tr>
                                            <td ><label><b>Country</b></label></td>
                                            <td  ><input class="field"
                                                  id="country" disabled="true" name="country"></input></td>
                                          </tr>
                                          
                            </table>

    
                         <select name="shoe" style="margin-left: 25%;">
                                  <option value="sport">sport shoe</option>
                                  <option value="canvas">canvas/sneakers</option>
                                  <option value="heels">Heels/Sandals</option>
                                  <option value="leather">Leather/Suede</option>
                                  <option value="ankle">Ankle length suede/Leather</option>
                                  <option value="knee">knee suede/Leather</option>
                        </select>
                        <input type="text" name="pair" placeholder="No of pairs" style="width: 10%" required>

                                
                            <button type="submit" name="submit" style="margin-left: 28%;">Next</button></br>
                            
                          </div>
                          </form>

                          
   
        
    </div>



    </div>
      
    </div>
     <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAqOxxOXdbQCISpcbHlJZMNbi9UIeTAfxk&libraries=places&callback=initAutocomplete"
        async defer></script>
    
    <div class="col-lg-offset-0 col-md-12 col-md-offset-4"></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>