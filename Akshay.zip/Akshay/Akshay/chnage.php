<?php
 require ('Connection.php');
                    session_start();
                    $aid=$_SESSION['aid'];
                    $name=$_SESSION['name'];
                    $email=$_SESSION['email'];

           if($aid==null)
        {
            header("location:index.php");
        }
        
             if(isset($_REQUEST['submit']))
             {
             	echo "Change";
             } 
             if(isset($_REQUEST['delete']))
             {
             	echo "Delete";
             }


?>