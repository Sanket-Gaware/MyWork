<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
</head>

<body>
<?php
 require ('Connection.php');
                    session_start();
                    $aid=$_SESSION['aid'];
                    $name=$_SESSION['name'];
                    $email=$_SESSION['email'];

           if($aid==null)
        {
            header("location:index.php");
        }
        
              


?>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="active" role="presentation"><a href="view-new.php">View New Orders</a></li>
                    <li role="presentation"><a href="check-status.php"> Check Status</a></li>
                    <li role="presentation"><a href="view-order-id.php"> View Order Id </a></li>
                    <li role="presentation"><a href="message.php">Message</a></li>
                    
                       <li role="presentation"><a href="report.php">Report</a></li>
                        <li role="presentation"><a href="send-notofication.php">Send Notification</a></li>

                    <li role="presentation"><a href="Log_out.php">log Out</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <center><h1>Welcome  <?php echo $name;?></h1></center>
    <center><h1>Todays Order</h1></center>
    <form action="change.php" method="POST">
      <div class="col-lg-7 col-lg-offset-3 col-md-6" style="margin-left: 25%;">

        <?php
        $date  = date('Y-m-d');
              $query = "select  *from `book` where date LIKE '$date%'";

              $result  = mysqli_query($con, $query);
              $revenue = 0;
              if (mysqli_affected_rows($con) != 0) 
              {
                  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
                   {
                   echo "     <table class='table table-hover'>";
                    echo "<tr><th>Order Id</th><th>".$row["bid"]."</th>";
                     echo "<tr><th>Name:-</th><th>".$row["uname"]."</th></tr>";
                     echo "<tr><th>Contact No:-</th><th>".$row["mobile"]."</th></tr>";
                    echo "</table>";
                    echo "<table class='table table-hover'>";
                    echo "<tr><th>Qty</th><th>Item Name</th><th>Price</th></tr>";
                    echo "<tr><td>".$row["pair"]."</td><td>".$row["shoe"]."</td><td>".$row["price"]."</td></tr>";
                    echo "<tr><td></td><td></td><td>Total:-".$row["price"]."</td></tr>";
                   // echo "<tr><th></th><th><button type='submit' name='delete' value=".$row["bid"].">Delete Order</button></th><th>
                    //  <button type='submit' name='submit' value=".$row["bid"].">Chnage Status</button></th></tr>";
                   
                    echo "</table>";
                    echo"<button type='submit' name='delete' value=".$row["bid"].">Delete Order</button>"; 
                    echo"&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;";
                    echo"<button type='submit' name='submit' value=".$row["bid"].">Change Status</button>";
                  }
              }

              ?>
              </div>
              </form>


    <div class="col-lg-offset-0 col-md-12 col-md-offset-4"></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>


</html>