<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
     <style type="text/css">
.val_error{
    color: #FF1F1F;
}

      </style>
        <script type="text/javascript">
            
    
            function Validate() 
            {
            var regex = /^([0-9a-zA-Z]([-_\\.]*[0-9a-zA-Z]+)*)@([0-9a-zA-Z]([-_\\.]*[0-9a-zA-Z]+)*)[\\.]([a-zA-Z]{2,9})$/;
            
                var email = document.getElementById("email").value;
        
                if (!regex.test(email) || email=="")
                  {
                    
                                            
                    document.getElementById("email").style.borderColor="red";
                    email_error.textContent = "Email is required";
                        return false;
                  
                  }
                 
                 else
                 {
                    return true;
                 }

                
            }
        
        </script>
</head>

<body>
<?php
session_start();
session_destroy();

?>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                 <li role="presentation"><a href="index.php">Home </a></li>
                    <li role="presentation"><a href="features.php">Book Now</a></li>
                    <li role="presentation"><a href="professional_login.php">Admin LogIn</a></li>
                    <li class="active"role="presentation"><a href="view.php">User LogIn</a></li>
                    
                    <li role="presentation"><a href="about.php">About Us</a></li>
                    <li role="presentation"><a href="contact_us.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav>
   <div class="col-md-11">
                                
                          <div class="imgcontainer">
                    
                          </div>

                          <div class="container"  >


                          <div class=" row">
                          <div class="col-md-5 col-md-offset-4" style="padding:20px; "> 
                          <form action="view-in.php" method="POST" onsubmit="return Validate()">
                         <center><h1>View Order </h1><img src="new.png" height="30%" width="60%"></center></br>
                            <label><b>Email</b></label>&emsp13;&emsp13;&emsp13;&emsp13;&emsp;
                            <input type="text" placeholder="Enter Email" name="email" id="email"  required> </br>
                             <div id="email_error" class="val_error"></div>

                            <label><b>Order Id</b></label>
                            <input type="text" placeholder="Enter Order id" name="order"  required></br>
                           
                            <button type="submit" name="submit" >Login</button></br>
                    
                          </div>
  </form>
  </div>
  </div>
                     
                            </div>
    <div class="col-lg-offset-0 col-md-12 col-md-offset-4"></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>