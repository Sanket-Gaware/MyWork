<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
</head>

<body>
<?php
 require ('Connection.php');
                    session_start();
                    $aid=$_SESSION['aid'];
                    $name=$_SESSION['name'];
                    $email=$_SESSION['email'];

           if($aid==null)
        {
            header("location:index.php");
        }
        
              


?>
  <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
<a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                    <li role="presentation"><a href="view-new.php">View New Orders</a></li>

                    <li role="presentation"><a href="Dashboard.php"> Dashboard</a></li>
                    
                    <li role="presentation"><a href="check-status.php"> Check Status</a></li>
                    <li role="presentation"><a href="view-order-id.php"> View Order Id </a></li>
                    <li role="presentation"><a href="message.php">Message</a></li>
                    
                       <li role="presentation"><a href="report.php">Report</a></li>
                        <li class="active" role="presentation"><a href="send-notofication.php">Send Notification</a></li>
                     
                
                    <li role="presentation"><a href="Log_out.php">log Out</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <form action="send-notofication.php" method="POST">
  <center> <h1>Send cleaning and processing of shoes complete message or any other Query</h1></center>
   <center><label>Order id</label><input type="text" name="bid" placeholder="order id" style="width: 10%;" required></center>
   <center><label>Message</label><textarea name="msg" rows="5" cols="30" required></textarea></center>
   <center><button type="submit" name="send">send</button></center>

   </form>
   <?php 
            if(isset($_REQUEST['send']))
            {
              $bid=$_REQUEST['bid'];
              $msg=$_REQUEST['msg'];
              $query=mysqli_query($con,"INSERT INTO `message`(`bid`, `message`) VALUES ('$bid','$msg')");

              if($query)
              {
                  echo "<center><h1> Message Sent Successfully </h1></center>";
              }
            
            }
   ?>


    <div class="col-lg-offset-0 col-md-12 col-md-offset-4"></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>


</html>