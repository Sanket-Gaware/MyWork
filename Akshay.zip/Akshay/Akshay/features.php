
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C:\Users\Hack\Desktop\index</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="assets/bootstrap/fonts/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="reg.css">
    <link rel="stylesheet" type="text/css" href="mk.css">
    <style type="text/css">
    	ul.b {list-style-type: square;
    			font-size: 15px;
    	}
    </style>
</head>

<body>
     <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="pull-left" href="index.php"> <img id="branding" src="Shoe.png" width="230px" height="50px"> </a>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav navbar-right">
                 <li role="presentation"><a href="index.php">Home </a></li>
                    <li class="active" role="presentation"><a href="features.php">Book Now</a></li>
                    <li role="presentation"><a href="professional_login.php">Admin LogIn</a></li>
                    <li role="presentation"><a href="view.php">User LogIn</a></li>
                    
                    <li role="presentation"><a href="about.php">About Us</a></li>
                    <li role="presentation"><a href="contact_us.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </nav>    <div class="col-lg-7 col-lg-offset-3 col-md-6" style="margin-left: 35%;">
    <h2>Shoe Laundry And Repair</h2><br></br>
    <h4> Features</h4><br></br>
       <ul class="b">
       	<li>Free pick up and delivery for all orders above Rs 399</li>
<li>Shoe Spa starting at Rs. 299</li>
<li>Prices are inclusive of taxes</li>
<li>Return within 6-10 days</li>

</ul>
<br></br><h4>Shoe spa include</h4><br></br>
<ul class="b">
<li>Cleaning with special solvents</li>
<li>Conditioning for non leather/patent leather shoes.</li>
<li>Leather shoes are treated with a leather conditioning gel</li>
<li>Buffing and creaming</li>
<li>Anti bacterial treatment</li>
<li>Anti fungal treatment</li>
<li>Anti skid gel to the bottom sole if necessary.</li>
<li>Deodorization</li>

       </ul>
       <a href="select_type.php"><button type="submit" > Next</button>
    </div>
    
    <div class="col-lg-offset-0 col-md-12 col-md-offset-4"></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>